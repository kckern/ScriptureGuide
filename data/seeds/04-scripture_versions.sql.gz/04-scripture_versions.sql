SET NAMES utf8mb4;
INSERT INTO `scripture_versions` (`id`,`index`,`priority`,`lang`,`title`,`title_long`,`credit`,`subtitle`,`desc`,`color`,`volumes`,`pagraph`,`img_ext`,`page_offset`,`fax_only`,`audio`,`searchable`,`audio_alias`) VALUES
('1830',1000,3,'en','1830 Palmyra Edition','1830 Palmyra Edition of the Book of Mormon','','','','','bom','','','',0,1,1,'LDS'),
('1833',2027,0,'en','Book of Commandments','Book of Commandments','','','','','dc','','','',0,0,0,NULL),
('1835',1039,0,'en','1835 Doctrine and Covenants','1835 Doctrine and Covenants','','','','','dc','','','',0,0,0,NULL),
('1837',1033,4,'en','1387 Kirtland Edition','1387 Kirtland Edition of the Book of Mormon','Edited by Joseph Smith','','','','bom','','','',0,1,1,'LDS'),
('1840',1036,5,'en','1840 Nauvoo Edition','1840 Nauvoo Edition of the Book of Mormon','Edited by Joseph Smith','','','','bom','','','',0,1,1,'LDS'),
('1841',2007,5,'en','1841 Liverpool Edition','1841 Liverpool Edition of the Book of Mormon','','','','','bom','','','',0,1,1,'LDS'),
('1879',2003,6,'en','1879 SLC Edition','1879 SLC Edition','Edited by Orson Pratt','','','','bom','','','',0,1,0,'LDS'),
('1920',1035,7,'en','1920 SLC Edition','1920 SLC Edition','Edited by James E. Talmage','','','','bom','','','',0,1,1,'LDS'),
('ASV',1003,15,'en','American Standard Version','American Standard Version','','','','','ot,nt','','','',0,0,1,NULL),
('KJV',1015,1,'en','King James Version','King James Version','','','','','ot,nt','','','',0,2,1,'LDS'),
('TYN',1046,29,'en','Tyndale Bible','Tyndale Bible','','','','','ot,nt','','','',0,0,1,NULL),
('WEB',2009,16,'en','World English Bible','World English Bible','','','','','ot,nt','','','',0,2,1,NULL);
