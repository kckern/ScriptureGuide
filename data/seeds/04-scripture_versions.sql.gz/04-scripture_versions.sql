SET NAMES utf8mb4;
INSERT INTO `scripture_versions` (`id`,`index`,`priority`,`lang`,`title`,`title_long`,`credit`,`subtitle`,`desc`,`color`,`volumes`,`pagraph`,`img_ext`,`page_offset`,`fax_only`,`audio`,`searchable`,`audio_alias`) VALUES
('ASV',1003,15,'en','American Standard Version','American Standard Version','','','','','ot,nt','','','',0,0,1,NULL),
('KJV',1015,1,'en','King James Version','King James Version','','','','','ot,nt','','','',0,2,1,'LDS'),
('WEB',2009,16,'en','World English Bible','World English Bible','','','','','ot,nt','','','',0,2,1,NULL);
