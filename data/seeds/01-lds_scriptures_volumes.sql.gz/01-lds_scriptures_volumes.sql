SET NAMES utf8mb4;
INSERT INTO `lds_scriptures_volumes` (`volume_id`,`volume_title`,`volume_title_med`,`volume_title_short`,`volume_title_long`,`volume_subtitle`,`lds_org`,`num_books`,`num_chapters`,`num_verses`) VALUES
(1,'Old Testament','Old Testament','Old Testament','The Old Testament','','ot',39,929,23145),
(2,'New Testament','New Testament','New Testament','The New Testament','Of our Lord and Saviour Jesus Christ','nt',27,260,7957),
(3,'Book of Mormon','Book of Mormon','Book of Mormon','The Book of Mormon','Another Testament of Jesus Christ','bm',15,239,6604),
(4,'Doctrine and Covenants','Doctrine & Covenants','D&C','The Doctrine and Covenants','','dc',1,138,3654),
(5,'Pearl of Great Price','Pearl of Great Price','Pearl of Great Price','The Pearl of Great Price','','pgp',5,16,635),
(6,'Lectures on Faith','Lectures on Faith','Lectures on Faith','Lectures on Faith','','lec',1,7,609),
(7,'JST Old Testament','JST Old Testament','JST Old Testament','The Inspired Old Testament','','jsto',39,929,23145),
(8,'JST New Testament','JST New Testament','JST New Testament','The Inspired New Testament','','jstn',27,260,0),
(9,'The Sealed Portion','The Sealed Portion','The Sealed Portion','The Sealed Portion','The Final Testament of Jesus Christ','tsp',3,102,0),
(10,'Law of the Lord','Law of the Lord','Law of the Lord','Law of the Lord','Strangite','lol',1,47,0),
(11,'Quran','Quran','Quran','Quran','Islam','qur',1,114,0),
(12,'Book of Commandments','Bk. of. Commands.','BoC','A Book of Commandments','Early D&C','boc',1,65,0),
(13,'1835 D&C','1835 D&C','1835 D&C','1835 D&C','1835 D&C','1835',1,111,0),
(14,'Dhammapada','Dham-mapada','Dhammapada','Dhammapada','','dham',1,26,423),
(15,'Bhagavad Gita','Bhagavad Gita','Bhagavad Gita','Bhagavad Gita','','gita',1,18,700),
(16,'Tao Te Ching','Tao Te Ching','Tao Te Ching','Tao Te Ching','','tao',1,81,81),
(17,'Sealed Book','Sealed Book','Sealed Book','The Sealed Book of Mormon','','sbom',3,31,716);
